#!/usr/bin/env python3
"""

TEMPLATE TP4 DDP1 Semester Gasal 2019/2020

Author: 
Ika Alfina (ika.alfina@cs.ui.ac.id)
Evi Yulianti (evi.yulianti@cs.ui.ac.id)
Meganingrum Arista Jiwanggi (meganingrum@cs.ui.ac.id)

Last update: 26 November 2019

"""
#Import semua modul yang diperlukan
from budayaKB_model import BudayaItem, BudayaCollection
from flask import Flask, request, render_template
from wtforms import *

'''
Membuat Form dengan menggunakan wtforms
'''
#InputForm untuk type input berupa text
class InputForm(Form):
        string_field = StringField(validators = [validators.InputRequired()])
class InputForm1(Form):
        string_field1 = StringField(validators = [validators.InputRequired()])
class InputForm2(Form):
        string_field2 = StringField(validators = [validators.InputRequired()]) 
class InputForm3(Form):
        string_field3 = StringField(validators = [validators.InputRequired()])

#SelectForm untuk type input berupa select
class SelectForm(Form):
        select_field = SelectField( choices = [('Nama Budaya','Nama Budaya'),\
                                               ('Tipe Budaya','Tipe Budaya'), \
                                               ('Asal Provinsi Budaya','Asal Provinsi Budaya')])
class SelectForm1(Form):
        select_field1 = SelectField(choices = [('All','All'),\
                                               ('Tipe Budaya', 'Tipe Budaya'),\
                                               ('Asal Provinsi Budaya','Asal Provinsi Budaya')])

#Memulai Flask        
app = Flask(__name__)
app.secret_key ="tp4"

#inisialisasi objek budayaData
budayaData = BudayaCollection()


#merender tampilan default(index.html)
@app.route('/')
def index():
        return render_template("index.html")

# Bagian ini adalah implementasi fitur Impor Budaya   
@app.route('/imporBudaya', methods=['GET', 'POST'])
def importData():
        if request.method == "GET":
                
                #merender tampilan saat menu Impor Budaya diklik
                return render_template("ImporBudaya.html")

        #melakukan pemrosesan terhadap isian form setelah tombol "Import Data" diklik
        elif request.method == "POST":
                budayaData.koleksi.clear()
                f = request.files['file']

                #Memasukkan nama file menjadi instance object dari budayaData
                budayaData.berkas = f.filename

                #File diimpor
                budayaData.importFromCSV(f.filename)
                n_data = len(budayaData.koleksi)

                #Tampilan setelah diproses dan menampilkan notifikasi jika berhasil
                return render_template("imporBudaya.html", result=n_data, fname=f.filename)

# Bagian ini adalah implementasi fitur Tambah Budaya 
@app.route('/tambahBudaya', methods=['GET', 'POST'])
def tambahBudaya():

        #Input Form diinisialisasi
        form_nama_budaya = InputForm(request.form)
        form_tipe_budaya = InputForm1(request.form)
        form_asal_budaya = InputForm2(request.form)
        form_URL = InputForm3(request.form)
        result = None

        #Pemrosesan setelah tombol budaya diklik
        if request.method == 'POST'\
           and form_nama_budaya.validate()\
           and form_tipe_budaya.validate()\
           and form_asal_budaya.validate()\
           and form_URL.validate() :

                #Instansiasi input-input dari user
                nama_budaya = form_nama_budaya.string_field.data
                tipe_budaya = form_tipe_budaya.string_field1.data
                asal_budaya = form_asal_budaya.string_field2.data
                URL = form_URL.string_field3.data

                #Data budaya dimasukkan ke dalam list 
                list1 = [ budaya.lower() for budaya in budayaData.koleksi.keys()]

                #Jika input nama budaya belum ada di dalam list tersebut, maka akan ditambahkan ke dalam list
                if nama_budaya.lower() not in list1:
                        result = ''
                        
                        #Menggunakan try and exception untuk mengecek apakah file sudah diimpor atau belum
                        try:

                                #Untuk mengecek hal di atas
                                type(budayaData.berkas)

                                #Budaya ditambahkan
                                budayaData.tambah(nama_budaya, tipe_budaya,\
                                                  asal_budaya, URL)

                                #Hasil pemrosesan langsung dimasukkan ke dalam berkas
                                budayaData.exportToCSV(budayaData.berkas)

                                #Notifikasi jika berhasil
                                result = 'Sukses menambahkan budaya ke dalam berkas'
                        except :

                                #Notifikasi jika file belum diimpor
                                result = 'File belum diimpor'
                else:
                        #Notifikasi jika nama budaya sudah ada di dalam file
                        result = 'Budaya sudah ada. Coba fitur "Ubah Budaya"'

        #Merender tampilan                
        return render_template('tambahBudaya.html',\
                               result = result,\
                               template_form = form_nama_budaya, \
                               template_form1 = form_tipe_budaya,\
                               template_form2 = form_asal_budaya,\
                               template_form3 = form_URL)
                               
#Bagian ini adalah implementasi fitur Ubah Budaya
@app.route('/ubahBudaya', methods=['GET', 'POST'])
def ubahBudaya():

        #Input Form diinisialisasi
        form_nama_budaya = InputForm(request.form)
        form_tipe_budaya = InputForm1(request.form)
        form_asal_budaya = InputForm2(request.form)
        form_URL = InputForm3(request.form)
        result = None

        #Pemrosesan setelah tombol ubah budaya diklik
        if request.method == 'POST'\
           and form_nama_budaya.validate()\
           and form_tipe_budaya.validate()\
           and form_asal_budaya.validate()\
           and form_URL.validate() :
                
                #Instansiasi input-input dari user
                nama_budaya = form_nama_budaya.string_field.data
                tipe_budaya = form_tipe_budaya.string_field1.data
                asal_budaya = form_asal_budaya.string_field2.data
                URL = form_URL.string_field3.data

                #Data budaya dimasukkan ke dalam list
                list1 = [ budaya.lower() for budaya in budayaData.koleksi.keys()]

                #Menggunakan try and exception untuk mengecek apakah file sudah diimpor atau belum
                try:

                        #Untuk mengecek hal di atas
                        type(budayaData.berkas)

                        #Jika input nama budaya sudah ada di dalam list tersebut, maka akan ditambahkan ke dalam list
                        if nama_budaya.lower() in list1:
                                result = ''

                                #Hal selanjutnya di bawah ini mirip dengan fitur tambah budaya 
                                budayaData.ubah(nama_budaya, tipe_budaya,\
                                                asal_budaya, URL)
                                budayaData.exportToCSV(budayaData.berkas)
                                result = 'Sukses Mengubah budaya'
                                
                        else:
                                result = 'Budaya belum ada. Coba fitur "Tambah Budaya"'
                except :
                        result = 'File belum diimpor'
        return render_template('ubahBudaya.html',\
                               result = result,\
                               template_form = form_nama_budaya, \
                               template_form1 = form_tipe_budaya,\
                               template_form2 = form_asal_budaya,\
                               template_form3 = form_URL)

#Bagian ini adalah implementasi fitur Hapus Budaya, mirip dengan fitur tambah dan ubah
@app.route('/hapusBudaya', methods=['GET', 'POST'])
def hapusBudaya():


        form_nama_budaya = InputForm(request.form)
        result = None

        
        if request.method == 'POST'\
           and form_nama_budaya.validate():
                
                nama_budaya = form_nama_budaya.string_field.data
                list1 = [ budaya.lower() for budaya in budayaData.koleksi.keys()]
                try:
                        type(budayaData.berkas)
                        if nama_budaya.lower() in list1:
                                result = ''
                                list_budaya = []
                                budayaData.hapus(nama_budaya)
                                budayaData.exportToCSV(budayaData.berkas)
                                result = 'Sukses Menghapus budaya'    
                        else:
                                result = 'Budaya tidak ada'
                except :
                        result = 'File belum diimpor'
        return render_template('hapusBudaya.html',\
                               result = result,\
                               template_form = form_nama_budaya)

#Bagian ini adalah implementasi fitur Cari Budaya
@app.route('/cariBudaya', methods=['GET', 'POST'])
def cariBudaya():

        #Form diinisialisasi
        select_form = SelectForm(request.form)
        input_form = InputForm(request.form)
        result = None
        tup1 = ''

        #Pemrosesan setelah tombol cari diklik
        if request.method == 'POST' and input_form.validate():

                #Instansiasi input-input dari user
                input_val = input_form.string_field.data
                select_val = select_form.select_field.data
                list1 = []

                #Jika input select berupa "Nama Budaya"
                if select_val == 'Nama Budaya':

                        #Input user dicari, acuannya adalah nama budaya tersebut 
                        list1 = budayaData.cariByNama(input_val)

                        #isi dari list1 berupa object sehingga list2 menjadikannya string
                        list2 = [ str(obj_budaya) for obj_budaya in list1]

                        #list3 menjadi list of list dengan list terdalam berupa [nama, tipe, asal, URL]
                        list3 = [ budaya.split(',') for budaya in list2]

                        #list terdalam dari list3 dijadikan tuple
                        tup1 = [tuple(budaya) for budaya in list3]

                        #Notifikasi jumlah dari yang dapat dicari tersebut
                        result = 'Ditemukan {} budaya berkaitan dengan pencarian'.format(\
                                len(list1))

                #Prosesnya mirip dengan di atas
                elif select_val == 'Tipe Budaya':
                        list1 = budayaData.cariByTipe(input_val)
                        list2 = [ str(obj_budaya) for obj_budaya in list1]
                        list3 = [ budaya.split(',') for budaya in list2]
                        tup1 = [tuple(budaya) for budaya in list3]
                        result = 'Ditemukan {} budaya berkaitan dengan pencarian'.format(\
                                len(list1))

                #Prosesnya mirip dengan di atas
                elif select_val == 'Asal Provinsi Budaya':
                        list1 = budayaData.cariByProv(input_val)
                        list2 = [ str(obj_budaya) for obj_budaya in list1]
                        list3 = [ budaya.split(',') for budaya in list2]
                        tup1 = [tuple(budaya) for budaya in list3]
                        result = 'Ditemukan {} budaya berkaitan dengan pencarian'.format(\
                                len(list1))

                #jika list tidak ada isinya, maka notifikasi ini yang akan keluar 
                if len(list1) == 0 :
                        result = 'Tidak ada "{}" di berkas ini'.format(input_val)
                        tup1 = ''

                #Try and Exception untuk mengecek apakah file sudah diimpor atau belum        
                try:
                        type(budayaData.berkas)
                except :
                        result = 'File belum diimpor'

        #Tampilan dari fitur Cari Budaya
        return render_template('cariBudaya.html',\
                               template_form = input_form,\
                               template_form1 = select_form,\
                               result = result,\
                               listBudaya = tup1)

#Bagian ini adalah implementasi fitur Statistik Budaya
@app.route('/statsBudaya', methods=['GET', 'POST'])
def statsBudaya():

        #Form diinisialisasi
        select_form = SelectForm1(request.form)
        result = None
        tup1 = ''

        #Pemrosesan setelah tombol tampilkan diklik
        if request.method == 'POST':

                #instansiasi input select dari user
                select_val = select_form.select_field1.data

                #Jika input select berupa "All"
                if select_val == 'All':

                        #Notifikasi berupa banyak data yang dimiliki berkas
                        result = 'Budaya KB memiliki total {} data budaya'.format(budayaData.stat())

                #Jika input select berupa "Tipe Budaya"
                elif select_val == 'Tipe Budaya':

                        #dict1 berupa dictionary
                        dict1 = budayaData.statByTipe()

                        #dijadikan tuple agar mudah dikeluarkan
                        tup1 = [(a,b) for a,b in dict1.items()]

                        #Notifikasi jika berhasil
                        result = 'Statistik Data Budaya berdasarkan Tipe Budaya'

                #Prosesnya mirip dengan di atas
                elif select_val == 'Asal Provinsi Budaya':
                        dict1 = budayaData.statByProv()
                        tup1 = [(a,b) for a,b in dict1.items()]
                        result = 'Statistik Data Budaya berdasarkan Asal Provinsi Budaya'

                #Try and Exception untuk mengecek apakah file sudah diimpor atau belum        
                try:
                        type(budayaData.berkas)
                except:
                        result = 'File belum diimpor'
                        tup1 = ''

        #Tampilan dari fitur Statistik Budaya
        return render_template('statsBudaya.html',\
                               template_form = select_form,\
                               result = result,\
                               budaya = tup1)
                

        

# run main app
if __name__ == "__main__":
        app.run(debug=True)



